extends Node3D
## Sphere Audio Editor (Godot 4.3+)
## Record or import audio -> each clip becomes a ball on a sphere around the listener.
## Drag the ball to move the sound in 360 degrees. Stack as many clips as you want (overlays),
## automate movement while playing, then download a binaural stereo WAV or a 4-channel
## first-order Ambisonic (360) WAV.

const SPHERE_R := 4.0
const MARKER_R := 0.28
const PICK_R := 0.42
const MIX_RATE := 44100
const MAX_ITD := 0.00066 # max interaural time difference in seconds

# ---------------------------------------------------------------- track data
class Track:
	var name := "Track"
	var samples := PackedFloat32Array() # mono, -1..1
	var rate := 44100
	var offset := 0.0 # start time on the timeline (seconds)
	var volume := 1.0
	var muted := false
	var dir := Vector3(0, 0, -1) # unit vector from listener to sound. Godot: -Z front, +X right, +Y up
	var keys: Array = [] # motion automation: [[time, Vector3], ...]
	var color := Color.WHITE
	var started := false
	var pivot: Node3D
	var mesh: MeshInstance3D
	var label: Label3D
	var player: AudioStreamPlayer3D

	func duration() -> float:
		return float(samples.size()) / float(rate)

	func dir_at(t: float) -> Vector3:
		if keys.is_empty():
			return dir
		var last := keys.size() - 1
		if t <= keys[0][0]:
			return keys[0][1]
		if t >= keys[last][0]:
			return keys[last][1]
		var lo := 0
		var hi := last
		while hi - lo > 1:
			var mid := (lo + hi) >> 1
			if keys[mid][0] <= t:
				lo = mid
			else:
				hi = mid
		var ta: float = keys[lo][0]
		var tb: float = keys[hi][0]
		var w := (t - ta) / maxf(tb - ta, 0.0001)
		var va: Vector3 = keys[lo][1]
		var vb: Vector3 = keys[hi][1]
		var v := va.lerp(vb, w)
		if v.length() < 0.001:
			return va
		return v.normalized()

var tracks: Array[Track] = []
var sel := -1
var playing := false
var recording := false
var play_time := 0.0
var pending_bytes := PackedByteArray()

var cam: Camera3D
var cam_yaw := 0.0
var cam_pitch := 0.35
var cam_dist := 10.5
var orbiting := false
var dragging: Track = null

var rec_effect: AudioEffectRecord
var mic_player: AudioStreamPlayer
var mix_player: AudioStreamPlayer

# UI references
var track_list: ItemList
var sel_box: VBoxContainer
var name_edit: LineEdit
var vol_slider: HSlider
var offset_spin: SpinBox
var mute_check: CheckBox
var az_slider: HSlider
var el_slider: HSlider
var key_label: Label
var rec_btn: Button
var motion_check: CheckBox
var time_label: Label
var status_label: Label
var open_dialog: FileDialog
var save_dialog: FileDialog


# ================================================================= setup
func _ready() -> void:
	OS.request_permissions() # microphone permission on mobile; harmless on desktop
	_build_world()
	_build_audio()
	_build_ui()
	_set_status("Ready. Press 'Record' or import a WAV. Use headphones for the 360 effect.")


func _build_world() -> void:
	var env := Environment.new()
	env.background_mode = Environment.BG_COLOR
	env.background_color = Color(0.07, 0.08, 0.11)
	env.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
	env.ambient_light_color = Color.WHITE
	env.ambient_light_energy = 0.7
	var we := WorldEnvironment.new()
	we.environment = env
	add_child(we)

	var light := DirectionalLight3D.new()
	light.rotation_degrees = Vector3(-45, 30, 0)
	add_child(light)

	cam = Camera3D.new()
	add_child(cam)
	_update_camera()

	# Fixed listener at the center, so orbiting the camera never changes the sound.
	var listener := AudioListener3D.new()
	add_child(listener)
	listener.make_current()

	_build_sphere_wire()
	_build_head()

	_add_text3d("FRONT", Vector3(0, 0, -SPHERE_R - 0.7))
	_add_text3d("BACK", Vector3(0, 0, SPHERE_R + 0.7))
	_add_text3d("LEFT", Vector3(-SPHERE_R - 0.8, 0, 0))
	_add_text3d("RIGHT", Vector3(SPHERE_R + 0.8, 0, 0))
	_add_text3d("UP", Vector3(0, SPHERE_R + 0.6, 0))
	_add_text3d("DOWN", Vector3(0, -SPHERE_R - 0.6, 0))


func _add_text3d(text: String, pos: Vector3) -> void:
	var l := Label3D.new()
	l.text = text
	l.position = pos
	l.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	l.pixel_size = 0.01
	l.font_size = 36
	l.modulate = Color(0.6, 0.65, 0.75)
	add_child(l)


func _build_sphere_wire() -> void:
	var im := ImmediateMesh.new()
	var mat := StandardMaterial3D.new()
	mat.shading_mode = BaseMaterial3D.SHADING_MODE_UNSHADED
	mat.albedo_color = Color(0.45, 0.55, 0.75, 0.55)
	mat.transparency = BaseMaterial3D.TRANSPARENCY_ALPHA
	for el_deg in [-60, -30, 0, 30, 60]:
		var el := deg_to_rad(float(el_deg))
		im.surface_begin(Mesh.PRIMITIVE_LINE_STRIP, mat)
		for k in range(65):
			var a := TAU * k / 64.0
			im.surface_add_vertex(_dir_from_angles(a, el) * SPHERE_R)
		im.surface_end()
	for az_deg in [0, 45, 90, 135]:
		var az := deg_to_rad(float(az_deg))
		im.surface_begin(Mesh.PRIMITIVE_LINE_STRIP, mat)
		for k in range(65):
			var u := TAU * k / 64.0
			im.surface_add_vertex(Vector3(sin(az) * cos(u), sin(u), -cos(az) * cos(u)) * SPHERE_R)
		im.surface_end()
	var mi := MeshInstance3D.new()
	mi.mesh = im
	add_child(mi)


func _build_head() -> void:
	var mat := StandardMaterial3D.new()
	mat.albedo_color = Color(0.7, 0.7, 0.75)
	var head := MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = 0.35
	sm.height = 0.7
	head.mesh = sm
	head.material_override = mat
	add_child(head)
	var nose := MeshInstance3D.new()
	var cm := CylinderMesh.new()
	cm.top_radius = 0.0
	cm.bottom_radius = 0.16
	cm.height = 0.4
	nose.mesh = cm
	nose.material_override = mat
	nose.position = Vector3(0, 0, -0.52)
	nose.rotation_degrees = Vector3(-90, 0, 0) # apex points to -Z (front)
	add_child(nose)


func _build_audio() -> void:
	# A bus that captures the microphone. The record effect comes first, then the bus is
	# turned all the way down so you don't hear yourself (no feedback).
	AudioServer.add_bus()
	var idx := AudioServer.bus_count - 1
	AudioServer.set_bus_name(idx, "Record")
	rec_effect = AudioEffectRecord.new()
	AudioServer.add_bus_effect(idx, rec_effect)
	var silence := AudioEffectAmplify.new()
	silence.volume_db = -80.0
	AudioServer.add_bus_effect(idx, silence)

	mic_player = AudioStreamPlayer.new()
	mic_player.stream = AudioStreamMicrophone.new()
	mic_player.bus = "Record"
	add_child(mic_player)
	mic_player.play()

	mix_player = AudioStreamPlayer.new()
	add_child(mix_player)


# ================================================================= UI
func _build_ui() -> void:
	var layer := CanvasLayer.new()
	add_child(layer)

	var panel := PanelContainer.new()
	layer.add_child(panel)
	panel.set_anchors_preset(Control.PRESET_LEFT_WIDE)
	panel.offset_left = 0
	panel.offset_right = 330
	panel.offset_top = 0
	panel.offset_bottom = 0

	var margin := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 10)
	panel.add_child(margin)
	var scroll := ScrollContainer.new()
	scroll.horizontal_scroll_mode = ScrollContainer.SCROLL_MODE_DISABLED
	margin.add_child(scroll)
	var box := VBoxContainer.new()
	box.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.add_theme_constant_override("separation", 6)
	scroll.add_child(box)

	var title := Label.new()
	title.text = "Sphere Audio Editor"
	title.add_theme_font_size_override("font_size", 20)
	box.add_child(title)

	# --- record / import
	rec_btn = _btn("● Record (overlay on playing tracks)", _toggle_record)
	box.add_child(rec_btn)
	box.add_child(_btn("Import WAV file…", func(): open_dialog.popup_centered(Vector2i(800, 500))))

	# --- transport
	box.add_child(HSeparator.new())
	var tr := HBoxContainer.new()
	tr.add_child(_btn("▶ Play", _play))
	tr.add_child(_btn("■ Stop", _stop))
	for b in tr.get_children():
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	box.add_child(tr)
	time_label = Label.new()
	time_label.text = "0.00 / 0.00 s"
	box.add_child(time_label)
	motion_check = CheckBox.new()
	motion_check.text = "Record motion (drag while playing)"
	box.add_child(motion_check)

	# --- track list
	box.add_child(HSeparator.new())
	var tl := Label.new()
	tl.text = "Tracks (overlays)"
	box.add_child(tl)
	track_list = ItemList.new()
	track_list.custom_minimum_size = Vector2(0, 110)
	track_list.item_selected.connect(_select)
	box.add_child(track_list)

	# --- selected track controls
	sel_box = VBoxContainer.new()
	sel_box.add_theme_constant_override("separation", 6)
	sel_box.visible = false
	box.add_child(sel_box)

	name_edit = LineEdit.new()
	name_edit.text_changed.connect(_on_name)
	sel_box.add_child(_row("Name", name_edit))
	vol_slider = _slider(0.0, 1.5, 0.01, 1.0, _on_volume)
	sel_box.add_child(_row("Volume", vol_slider))
	offset_spin = SpinBox.new()
	offset_spin.min_value = 0.0
	offset_spin.max_value = 600.0
	offset_spin.step = 0.01
	offset_spin.suffix = "s"
	offset_spin.value_changed.connect(_on_offset)
	sel_box.add_child(_row("Start at", offset_spin))
	mute_check = CheckBox.new()
	mute_check.text = "Mute"
	mute_check.toggled.connect(_on_mute)
	sel_box.add_child(mute_check)
	az_slider = _slider(-180.0, 180.0, 0.5, 0.0, _on_angle)
	sel_box.add_child(_row("Azimuth", az_slider))
	el_slider = _slider(-90.0, 90.0, 0.5, 0.0, _on_angle)
	sel_box.add_child(_row("Elevation", el_slider))
	key_label = Label.new()
	sel_box.add_child(key_label)
	var rowb := HBoxContainer.new()
	rowb.add_child(_btn("Clear motion", _clear_motion))
	rowb.add_child(_btn("Delete track", _delete_selected))
	for b in rowb.get_children():
		b.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	sel_box.add_child(rowb)

	# --- export
	box.add_child(HSeparator.new())
	var el := Label.new()
	el.text = "Mix & download"
	box.add_child(el)
	box.add_child(_btn("▶ Preview rendered 360 mix", _preview_mix))
	box.add_child(_btn("⬇ Download binaural stereo (.wav)", _export.bind("binaural")))
	box.add_child(_btn("⬇ Download 360 Ambisonic 4ch (.wav)", _export.bind("ambi")))

	status_label = Label.new()
	status_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	status_label.modulate = Color(0.8, 0.9, 1.0)
	box.add_child(status_label)

	# --- hint
	var hint := Label.new()
	hint.text = "Drag a ball to move its sound • drag empty space or right-drag to orbit • wheel = zoom"
	layer.add_child(hint)
	hint.position = Vector2(345, 8)
	hint.modulate = Color(0.7, 0.75, 0.85)

	# --- file dialogs
	open_dialog = FileDialog.new()
	open_dialog.file_mode = FileDialog.FILE_MODE_OPEN_FILE
	open_dialog.access = FileDialog.ACCESS_FILESYSTEM
	open_dialog.filters = PackedStringArray(["*.wav ; WAV audio"])
	open_dialog.file_selected.connect(_on_import_file)
	layer.add_child(open_dialog)

	save_dialog = FileDialog.new()
	save_dialog.file_mode = FileDialog.FILE_MODE_SAVE_FILE
	save_dialog.access = FileDialog.ACCESS_FILESYSTEM
	save_dialog.filters = PackedStringArray(["*.wav ; WAV audio"])
	save_dialog.file_selected.connect(_on_save_path)
	layer.add_child(save_dialog)


func _btn(text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.pressed.connect(cb)
	return b


func _slider(minv: float, maxv: float, step: float, val: float, cb: Callable) -> HSlider:
	var s := HSlider.new()
	s.min_value = minv
	s.max_value = maxv
	s.step = step
	s.value = val
	s.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	s.value_changed.connect(cb)
	return s


func _row(text: String, c: Control) -> HBoxContainer:
	var h := HBoxContainer.new()
	var l := Label.new()
	l.text = text
	l.custom_minimum_size.x = 80
	h.add_child(l)
	c.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	h.add_child(c)
	return h


func _set_status(t: String) -> void:
	status_label.text = t


# ================================================================= camera & mouse
func _update_camera() -> void:
	cam.position = Vector3(
		cos(cam_pitch) * sin(cam_yaw),
		sin(cam_pitch),
		cos(cam_pitch) * cos(cam_yaw)) * cam_dist
	cam.look_at(Vector3.ZERO, Vector3.UP)


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventMouseButton and event.pressed:
		if event.button_index == MOUSE_BUTTON_LEFT:
			var t := _pick_marker(event.position)
			if t != null:
				_select(tracks.find(t))
				dragging = t
			else:
				orbiting = true
		elif event.button_index == MOUSE_BUTTON_RIGHT:
			orbiting = true
		elif event.button_index == MOUSE_BUTTON_WHEEL_UP:
			cam_dist = clampf(cam_dist - 0.6, 5.0, 25.0)
			_update_camera()
		elif event.button_index == MOUSE_BUTTON_WHEEL_DOWN:
			cam_dist = clampf(cam_dist + 0.6, 5.0, 25.0)
			_update_camera()


func _input(event: InputEvent) -> void:
	# Releases and motion are read here so a drag never gets "stuck" when the mouse crosses the panel.
	if event is InputEventMouseButton and not event.pressed:
		if event.button_index == MOUSE_BUTTON_LEFT:
			dragging = null
			orbiting = false
		elif event.button_index == MOUSE_BUTTON_RIGHT:
			orbiting = false
	elif event is InputEventMouseMotion:
		if dragging != null:
			var o := cam.project_ray_origin(event.position)
			var n := cam.project_ray_normal(event.position)
			_apply_dir(dragging, _ray_to_dir(o, n))
			_sync_angles()
		elif orbiting:
			cam_yaw -= event.relative.x * 0.008
			cam_pitch = clampf(cam_pitch + event.relative.y * 0.008, -1.4, 1.4)
			_update_camera()


func _pick_marker(pos: Vector2) -> Track:
	var o := cam.project_ray_origin(pos)
	var n := cam.project_ray_normal(pos)
	var best: Track = null
	var best_t := INF
	for t in tracks:
		var oc := o - t.pivot.position
		var b := oc.dot(n)
		var disc := b * b - (oc.dot(oc) - PICK_R * PICK_R)
		if disc >= 0.0:
			var tt := -b - sqrt(disc)
			if tt > 0.0 and tt < best_t:
				best_t = tt
				best = t
	return best


## Where on the sphere is the mouse pointing? (near side of the sphere; orbit the camera for the back)
func _ray_to_dir(o: Vector3, d: Vector3) -> Vector3:
	var b := o.dot(d)
	var c := o.dot(o) - SPHERE_R * SPHERE_R
	var disc := b * b - c
	if disc >= 0.0:
		var t := -b - sqrt(disc)
		return (o + d * t).normalized()
	return (o + d * (-b)).normalized() # mouse is off the sphere: nearest direction


func _dir_from_angles(az: float, el: float) -> Vector3:
	return Vector3(sin(az) * cos(el), sin(el), -cos(az) * cos(el))


# ================================================================= tracks
func _cur() -> Track:
	if sel >= 0 and sel < tracks.size():
		return tracks[sel]
	return null


func _add_track(track_name: String, samples: PackedFloat32Array, rate: int) -> void:
	var t := Track.new()
	t.name = track_name
	t.samples = samples
	t.rate = rate
	t.color = Color.from_hsv(fmod(tracks.size() * 0.17, 1.0), 0.65, 1.0)
	t.dir = _dir_from_angles(deg_to_rad(fmod(tracks.size() * 60.0, 360.0)), 0.0)

	t.pivot = Node3D.new()
	add_child(t.pivot)
	t.pivot.position = t.dir * SPHERE_R

	t.mesh = MeshInstance3D.new()
	var sm := SphereMesh.new()
	sm.radius = MARKER_R
	sm.height = MARKER_R * 2.0
	t.mesh.mesh = sm
	var mat := StandardMaterial3D.new()
	mat.albedo_color = t.color
	mat.emission_enabled = true
	mat.emission = t.color
	mat.emission_energy_multiplier = 0.5
	t.mesh.material_override = mat
	t.pivot.add_child(t.mesh)

	t.label = Label3D.new()
	t.label.text = track_name
	t.label.billboard = BaseMaterial3D.BILLBOARD_ENABLED
	t.label.pixel_size = 0.01
	t.label.font_size = 36
	t.label.modulate = t.color
	t.label.no_depth_test = true
	t.label.position = Vector3(0, 0.55, 0)
	t.pivot.add_child(t.label)

	t.player = AudioStreamPlayer3D.new()
	t.player.stream = _data_to_stream(samples, rate, false)
	t.player.attenuation_model = AudioStreamPlayer3D.ATTENUATION_DISABLED # direction only, no distance fade
	t.pivot.add_child(t.player)

	tracks.append(t)
	sel = tracks.size() - 1
	_refresh_list()
	_select(sel)


func _refresh_list() -> void:
	track_list.clear()
	for t in tracks:
		track_list.add_item("%s  (%.1fs)" % [t.name, t.duration()])
	if sel >= 0 and sel < tracks.size():
		track_list.select(sel)


func _select(i: int) -> void:
	sel = i if (i >= 0 and i < tracks.size()) else -1
	var cur := _cur()
	for t in tracks:
		t.mesh.scale = Vector3.ONE * (1.45 if t == cur else 1.0)
	sel_box.visible = sel >= 0
	if sel >= 0:
		track_list.select(sel)
		_sync_ui()


func _sync_ui() -> void:
	var t := _cur()
	if t == null:
		return
	name_edit.text = t.name
	vol_slider.set_value_no_signal(t.volume)
	offset_spin.set_value_no_signal(t.offset)
	mute_check.set_pressed_no_signal(t.muted)
	_sync_angles()


func _sync_angles() -> void:
	var t := _cur()
	if t == null:
		return
	var d := t.dir
	az_slider.set_value_no_signal(rad_to_deg(atan2(d.x, -d.z)))
	el_slider.set_value_no_signal(rad_to_deg(asin(clampf(d.y, -1.0, 1.0))))
	key_label.text = "Motion keyframes: %d" % t.keys.size()


func _apply_dir(t: Track, d: Vector3) -> void:
	t.dir = d
	if motion_check.button_pressed and playing:
		# overwrite anything recorded later than "now", then add a keyframe
		while not t.keys.is_empty() and t.keys.back()[0] >= play_time:
			t.keys.pop_back()
		t.keys.append([play_time, d])
	else:
		t.keys.clear() # fixed position
	t.pivot.position = d * SPHERE_R


func _on_name(new_text: String) -> void:
	var t := _cur()
	if t == null:
		return
	t.name = new_text
	t.label.text = new_text
	_refresh_list()


func _on_volume(v: float) -> void:
	var t := _cur()
	if t == null:
		return
	t.volume = v
	_update_player_volume(t)


func _on_mute(p: bool) -> void:
	var t := _cur()
	if t == null:
		return
	t.muted = p
	_update_player_volume(t)


func _update_player_volume(t: Track) -> void:
	t.player.volume_db = -80.0 if t.muted else linear_to_db(maxf(t.volume, 0.0001))


func _on_offset(v: float) -> void:
	var t := _cur()
	if t != null:
		t.offset = v


func _on_angle(_v: float) -> void:
	var t := _cur()
	if t == null:
		return
	_apply_dir(t, _dir_from_angles(deg_to_rad(az_slider.value), deg_to_rad(el_slider.value)))
	key_label.text = "Motion keyframes: %d" % t.keys.size()


func _clear_motion() -> void:
	var t := _cur()
	if t != null:
		t.keys.clear()
		_sync_angles()


func _delete_selected() -> void:
	var t := _cur()
	if t == null:
		return
	_stop()
	t.pivot.queue_free()
	tracks.erase(t)
	sel = -1
	_refresh_list()
	_select(-1)


# ================================================================= recording / import
func _toggle_record() -> void:
	if not recording:
		recording = true
		rec_effect.set_recording_active(true)
		rec_btn.text = "■ Stop recording"
		_play() # existing tracks play so you can overlay in time
		_set_status("Recording… existing tracks are playing so you can overlay. Use headphones so the mic doesn't hear them.")
	else:
		rec_effect.set_recording_active(false)
		recording = false
		rec_btn.text = "● Record (overlay on playing tracks)"
		_stop()
		var wav := rec_effect.get_recording()
		if wav == null:
			_set_status("Nothing was recorded. Check your microphone / permissions.")
			return
		var mono := _wav_to_mono(wav)
		if mono.size() < 100:
			_set_status("Recording was empty or not 16-bit. Check your microphone.")
			return
		_add_track("Rec %d" % (tracks.size() + 1), mono, wav.mix_rate)
		_set_status("Recorded %.1fs. Drag its ball around the sphere!" % (mono.size() / float(wav.mix_rate)))


func _wav_to_mono(w: AudioStreamWAV) -> PackedFloat32Array:
	var out := PackedFloat32Array()
	if w.format != AudioStreamWAV.FORMAT_16_BITS:
		return out
	var d := w.data
	var ch := 2 if w.stereo else 1
	var frames := d.size() / (2 * ch)
	out.resize(frames)
	for f in frames:
		var acc := 0
		for c in ch:
			acc += d.decode_s16((f * ch + c) * 2)
		out[f] = float(acc) / float(ch) / 32768.0
	return out


func _on_import_file(path: String) -> void:
	var bytes := FileAccess.get_file_as_bytes(path)
	var parsed := _parse_wav(bytes)
	if parsed.is_empty():
		_set_status("Couldn't read that file. Supported: PCM WAV (8/16/24/32-bit) or 32-bit float WAV.")
		return
	_add_track(path.get_file().get_basename(), parsed["samples"], parsed["rate"])
	_set_status("Imported %s (%.1fs)." % [path.get_file(), parsed["samples"].size() / float(parsed["rate"])])


func _parse_wav(bytes: PackedByteArray) -> Dictionary:
	if bytes.size() < 44 or bytes.slice(0, 4).get_string_from_ascii() != "RIFF":
		return {}
	var pos := 12
	var tag := 0
	var ch := 0
	var rate := 0
	var bits := 0
	var data_start := -1
	var data_len := 0
	while pos + 8 <= bytes.size():
		var id := bytes.slice(pos, pos + 4).get_string_from_ascii()
		var sz := bytes.decode_u32(pos + 4)
		if id == "fmt ":
			tag = bytes.decode_u16(pos + 8)
			ch = bytes.decode_u16(pos + 10)
			rate = bytes.decode_u32(pos + 12)
			bits = bytes.decode_u16(pos + 22)
			if tag == 0xFFFE and sz >= 40:
				tag = bytes.decode_u16(pos + 32) # WAVE_FORMAT_EXTENSIBLE sub-format
		elif id == "data":
			data_start = pos + 8
			data_len = mini(sz, bytes.size() - data_start)
			break
		pos += 8 + sz + (sz & 1)
	if data_start < 0 or ch < 1 or bits < 8 or rate < 1000:
		return {}
	var bps := bits / 8
	var frames := data_len / (ch * bps)
	var out := PackedFloat32Array()
	out.resize(frames)
	for f in frames:
		var acc := 0.0
		for c in ch:
			var p := data_start + (f * ch + c) * bps
			if tag == 3 and bits == 32:
				acc += bytes.decode_float(p)
			elif bits == 16:
				acc += bytes.decode_s16(p) / 32768.0
			elif bits == 8:
				acc += (bytes[p] - 128) / 128.0
			elif bits == 24:
				var v := bytes[p] | (bytes[p + 1] << 8) | (bytes[p + 2] << 16)
				if v >= 0x800000:
					v -= 0x1000000
				acc += v / 8388608.0
			elif bits == 32:
				acc += bytes.decode_s32(p) / 2147483648.0
		out[f] = acc / float(ch)
	return {"samples": out, "rate": rate}


# ================================================================= playback
func _play() -> void:
	mix_player.stop()
	for t in tracks:
		t.player.stop()
		t.started = false
		_update_player_volume(t)
	play_time = 0.0
	playing = true


func _stop() -> void:
	playing = false
	mix_player.stop()
	for t in tracks:
		t.player.stop()
		t.started = false
		if not t.keys.is_empty():
			t.dir = t.dir_at(0.0)


func _process(delta: float) -> void:
	if playing:
		play_time += delta
		for t in tracks:
			if not t.keys.is_empty():
				t.dir = t.dir_at(play_time)
			if not t.started and play_time >= t.offset:
				t.started = true
				t.player.play()
		var cur := _cur()
		if cur != null and not cur.keys.is_empty() and dragging == null:
			_sync_angles()
		if not recording and play_time > _timeline_length() + 0.3:
			_stop()
	for t in tracks:
		t.pivot.position = t.dir * SPHERE_R
	time_label.text = "%.2f / %.2f s" % [play_time if playing else 0.0, _timeline_length()]


func _timeline_length() -> float:
	var m := 0.0
	for t in tracks:
		m = maxf(m, t.offset + t.duration())
	return m


# ================================================================= offline rendering
func _fetch(s: PackedFloat32Array, p: float) -> float:
	if p < 0.0:
		return 0.0
	var i0 := int(p)
	if i0 >= s.size() - 1:
		return 0.0
	var f := p - float(i0)
	return s[i0] * (1.0 - f) + s[i0 + 1] * f


## mode "binaural" -> interleaved stereo (headphone 360 mix: level + time difference + head shadow + front/back cue)
## mode "ambi"     -> interleaved 4ch first-order Ambisonics, AmbiX (ACN order W,Y,Z,X, SN3D)
func _render(mode: String) -> PackedFloat32Array:
	var ambi := mode == "ambi"
	var ch := 4 if ambi else 2
	var total := int(ceil((_timeline_length() + 0.1) * MIX_RATE))
	var out := PackedFloat32Array()
	out.resize(total * ch)
	out.fill(0.0)
	var max_delay := MAX_ITD * MIX_RATE

	for t in tracks:
		if t.muted or t.samples.size() < 2:
			continue
		var s := t.samples
		var ratio := float(t.rate) / float(MIX_RATE)
		var start_i := int(t.offset * MIX_RATE)
		var end_i := mini(total, start_i + int(float(s.size()) / ratio) + int(max_delay) + 2)
		var vol := t.volume
		var gl := 0.7
		var gr := 0.7
		var dl := 0.0
		var dr := 0.0
		var aL := 1.0
		var aR := 1.0
		var wx := 0.0
		var wy := 0.0
		var wz := 0.0
		var lpL := 0.0
		var lpR := 0.0
		for i in range(start_i, end_i):
			if (i - start_i) % 128 == 0:
				var d := t.dir_at(float(i) / MIX_RATE)
				if ambi:
					# Godot (-Z front, +X right, +Y up) -> AmbiX (+X front, +Y left, +Z up)
					wx = -d.z * vol
					wy = -d.x * vol
					wz = d.y * vol
				else:
					var ang := (d.x + 1.0) * PI * 0.25 # equal-power pan
					var back := maxf(d.z, 0.0)
					var bg := 1.0 - 0.3 * back
					gl = cos(ang) * bg * vol
					gr = sin(ang) * bg * vol
					dl = maxf(d.x, 0.0) * max_delay # far ear hears it later
					dr = maxf(-d.x, 0.0) * max_delay
					aL = lerpf(1.0, 0.3, clampf(maxf(d.x, 0.0) * 0.8 + back * 0.5, 0.0, 1.0)) # head shadow
					aR = lerpf(1.0, 0.3, clampf(maxf(-d.x, 0.0) * 0.8 + back * 0.5, 0.0, 1.0))
			var rel := float(i - start_i)
			if ambi:
				var v := _fetch(s, rel * ratio)
				var o4 := i * 4
				out[o4] += v * vol
				out[o4 + 1] += v * wy
				out[o4 + 2] += v * wz
				out[o4 + 3] += v * wx
			else:
				var vl := _fetch(s, (rel - dl) * ratio) * gl
				var vr := _fetch(s, (rel - dr) * ratio) * gr
				lpL += aL * (vl - lpL)
				lpR += aR * (vr - lpR)
				out[i * 2] += lpL
				out[i * 2 + 1] += lpR

	var peak := 0.0
	for v in out:
		peak = maxf(peak, absf(v))
	if peak > 0.98:
		var k := 0.98 / peak
		for i in out.size():
			out[i] *= k
	return out


func _to_pcm16(data: PackedFloat32Array) -> PackedByteArray:
	var pcm := PackedByteArray()
	pcm.resize(data.size() * 2)
	for i in data.size():
		pcm.encode_s16(i * 2, int(clampf(data[i], -1.0, 1.0) * 32767.0))
	return pcm


func _data_to_stream(data: PackedFloat32Array, rate: int, stereo: bool) -> AudioStreamWAV:
	var s := AudioStreamWAV.new()
	s.format = AudioStreamWAV.FORMAT_16_BITS
	s.mix_rate = rate
	s.stereo = stereo
	s.data = _to_pcm16(data)
	return s


func _make_wav_bytes(data: PackedFloat32Array, channels: int, rate: int) -> PackedByteArray:
	var pcm := _to_pcm16(data)
	var h := StreamPeerBuffer.new() # little-endian by default
	h.put_data("RIFF".to_ascii_buffer())
	h.put_u32(36 + pcm.size())
	h.put_data("WAVE".to_ascii_buffer())
	h.put_data("fmt ".to_ascii_buffer())
	h.put_u32(16)
	h.put_u16(1) # PCM
	h.put_u16(channels)
	h.put_u32(rate)
	h.put_u32(rate * channels * 2)
	h.put_u16(channels * 2)
	h.put_u16(16)
	h.put_data("data".to_ascii_buffer())
	h.put_u32(pcm.size())
	var bytes := h.data_array
	bytes.append_array(pcm)
	return bytes


func _preview_mix() -> void:
	if tracks.is_empty():
		_set_status("Add a track first.")
		return
	_stop()
	_set_status("Rendering preview…")
	await get_tree().process_frame
	await get_tree().process_frame
	var data := _render("binaural")
	mix_player.stream = _data_to_stream(data, MIX_RATE, true)
	mix_player.play()
	_set_status("Playing the rendered mix — this is exactly what the download will sound like. Use headphones.")


func _export(mode: String) -> void:
	if tracks.is_empty():
		_set_status("Add a track first.")
		return
	_stop()
	_set_status("Rendering… (long projects can take a few seconds)")
	await get_tree().process_frame
	await get_tree().process_frame
	var ch := 4 if mode == "ambi" else 2
	var bytes := _make_wav_bytes(_render(mode), ch, MIX_RATE)
	var fname := "sphere_mix_360_ambisonic_4ch.wav" if mode == "ambi" else "sphere_mix_binaural.wav"
	if OS.has_feature("web"):
		JavaScriptBridge.download_buffer(bytes, fname, "audio/wav")
		_set_status("Downloaded " + fname)
	else:
		pending_bytes = bytes
		save_dialog.current_file = fname
		save_dialog.popup_centered(Vector2i(800, 500))
		_set_status("Choose where to save your file.")


func _on_save_path(path: String) -> void:
	if not path.to_lower().ends_with(".wav"):
		path += ".wav"
	var f := FileAccess.open(path, FileAccess.WRITE)
	if f == null:
		_set_status("Couldn't save: " + error_string(FileAccess.get_open_error()))
		return
	f.store_buffer(pending_bytes)
	f.close()
	_set_status("Saved to " + path)
