SPHERE AUDIO EDITOR (Godot 4.3 or newer)

1. Open Godot -> Import -> select project.godot -> Run (F5).
2. Click "Record", talk, click "Stop recording". A ball appears on the sphere.
3. Drag the ball around the sphere (or use Azimuth / Elevation sliders). Drag empty space to orbit the camera.
4. Record again to overlay another track (existing tracks play while you record). Use headphones!
5. "Record motion": tick it, press Play, then drag a ball while it plays -> the movement is saved.
6. Download: binaural stereo WAV (headphones) or 4-channel Ambisonic WAV (true 360 format).
